// Function to change the featured image and title
function changeImage(imageSrc, imageTitle) {
    var featuredImage = document.getElementById('featured-image'); // Get the featured image element
    var imageTitleElement = document.getElementById('image-title'); // Get the image title element

    // Preload the new image
    var preloadImage = new Image();
    preloadImage.src = 'images/' + imageSrc;

    // Once the new image is loaded, update the featured image and title with a fade-in effect
    preloadImage.onload = function() {
        // Hide the featured image before changing the source
        featuredImage.style.opacity = 0;

        // Update the featured image source and title
        featuredImage.src = preloadImage.src;
        imageTitleElement.textContent = imageTitle;

        // Fade in the featured image
        fadeInImage(featuredImage);
    };
}

// Function to fade in the image
function fadeInImage(imageElement) {
    var opacity = 0; // Initial opacity value

    var fadeInterval = setInterval(function() {
        if (opacity < 1) {
            opacity += 0.1; // Increase opacity gradually
            imageElement.style.opacity = opacity;
        } else {
            clearInterval(fadeInterval); // Clear the interval once opacity reaches 1
        }
    }, 50); // Interval for smooth fade-in effect
}
